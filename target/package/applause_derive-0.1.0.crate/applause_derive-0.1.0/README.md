# Applause_Derive

This crate is the derive macro implementation for the Applause crate.  Please look there for documentation.
